close all;      clear;      clc;

%% The following code shows the resampling thecnique for 1$ recognizer paper

H0 = csvread("T0");          
H1 = csvread("T1");          
H2 = csvread("T2");          
H3 = csvread("T3");          
H4 = csvread("T4");         
H5 = csvread("T5");       
H6 = csvread("T6");       
H7 = csvread("T7");         
H8 = csvread("T8");     
H9 = csvread("T9");          
Hx = [H0(:,1),H1(:,1),H2(:,1),H3(:,1),H4(:,1),H5(:,1),H6(:,1),H7(:,1),H8(:,1),H9(:,1)];
Hy = [H0(:,2),H1(:,2),H2(:,2),H3(:,2),H4(:,2),H5(:,2),H6(:,2),H7(:,2),H8(:,2),H9(:,2)]; 
Cpts = csvread("Data");         Cpts(:,3)=[];

% figure
% subplot(431);     plot(T0(:,1),T0(:,2),'k.');
% hold on;          plot(T0(1,1),T0(1,2),'ro')
% subplot(432);     plot(T1(:,1),T1(:,2),'k.');
% hold on;          plot(T1(1,1),T1(1,2),'ro')
% subplot(433);     plot(T2(:,1),T2(:,2),'k.');
% hold on;          plot(T2(1,1),T2(1,2),'ro')
% subplot(434);     plot(T3(:,1),T3(:,2),'k.');
% hold on;          plot(T3(1,1),T3(1,2),'ro')
% subplot(435);     plot(T4(:,1),T4(:,2),'k.');
% hold on;          plot(T4(1,1),T4(1,2),'ro')
% subplot(436);     plot(T5(:,1),T5(:,2),'k.');
% hold on;          plot(T5(1,1),T5(1,2),'ro')
% subplot(437);     plot(T6(:,1),T6(:,2),'k.');
% hold on;          plot(T6(1,1),T6(1,2),'ro')
% subplot(438);     plot(T7(:,1),T7(:,2),'k.');
% hold on;          plot(T7(1,1),T7(1,2),'ro')
% subplot(439);     plot(T8(:,1),T8(:,2),'k.');
% hold on;          plot(T8(1,1),T8(1,2),'ro')
% subplot(4,3,10);  plot(T9(:,1),T9(:,2),'k.');
% hold on;          plot(T9(1,1),T9(1,2),'ro')    


AllTemplate = {Cpts};          % insert after testing
nT = length(AllTemplate);       % Number of templates
Pr = ones(64,3,nT);             % the resampled points

for k=1:nT
    buf = AllTemplate{k};
    d = diff(buf);
    L = cumsum(sqrt(d(:,1).^2+d(:,2).^2));
    L = [0;L];

    Pr(1,1:2,k) = buf(1,:);
    Pr(64,1:2,k) = buf(end,:);
    dL = L(end)/63;

    for i=1:62
        id = find(L>i*dL);          
        e = id(1);
        s = id(1)-1;
        a = (i*dL-L(s))/(L(e)-L(s));
        %Pr(i+1,:,k) = a*buf(s,:)+(1-a)*buf(e,:);       
        B = buf(s,:)-Pr(i,1:2,k);
        en = (buf(e,:)-buf(s,:)) \ norm((buf(e,:)-buf(s,:)));       
        peq = [1 , 2*B*en , norm(B)^2-dL^2];
        a2 = roots(peq);
        Pr(i+1,1:2,k) = buf(s,:)+a2(2)*en';
    end
    
%     figure
%     plot(AllTemplate{k}(:,1),AllTemplate{k}(:,2),'k.');
%     hold on
%     plot(Pr(:,1,k),Pr(:,2,k),'rs');
%     axis equal
     
    C(k,:) = mean(Pr(:,:,k));  %centroid for resampled points before rotation
    
    Pr_0(:,1,k) = Pr(:,1,k) - C(k,1); %resampled points at origin
    Pr_0(:,2,k) = Pr(:,2,k) - C(k,2);

    C_origin(k,:) = mean(Pr_0(:,1:2,k));   %centroid is brought to (0,0) origin 
    Pr_0(:,3) = 0;

    theta(k,:) = atan((Pr_0(1,2,k)-C_origin(k,2))/(Pr_0(1,1,k)-C_origin(k,1)));
    R = [cos(theta(k)) sin(theta(k)) 0 ; -sin(theta(k)) cos(theta(k)) 0; 0 0 1];
%    T = eye(3); T(1,3) = -C_origin(1);     T(2,3)= -C_origin(2);
    Pr_rot(:,:,k) = Pr_0(:,:,k)*R;  % resampled points after rotation
    C1(k,:) = mean(Pr_rot(:,:,k));  % centroid after rotation
    
    Xmin(k) = min(real(Pr_rot(:,1,k)));
    Xmax(k) = max(real(Pr_rot(:,1,k)));
    Ymin(k) = min(real(Pr_rot(:,2,k)));
    Ymax(k) = max(real(Pr_rot(:,2,k)));
    
    SqrLength(k,1) = abs(Xmax(k)-Xmin(k));
    SqrHeight(k,1) = abs(Ymax(k)-Ymin(k));
    squareSize = 1;

    Pr_new_1(:,1,k) = (Pr_rot(:,1,k).*squareSize./SqrLength(k,1));
    Pr_new_1(:,2,k) = (Pr_rot(:,2,k).*squareSize./SqrHeight(k,1));
    
    newXmin(k) = min(real(Pr_new_1(:,1,k)));
    newXmax(k) = max(real(Pr_new_1(:,1,k)));
    newYmin(k) = min(real(Pr_new_1(:,2,k)));
    newYmax(k) = max(real(Pr_new_1(:,2,k)));
    
    C_final(:,1,k) = Pr_new_1(:,1,k) + abs(newXmin(k));
    C_final(:,2,k) = Pr_new_1(:,2,k) + abs(newYmin(k));
    
%     figure
%     plot(C_final(:,1,k),C_final(:,2,k),'.')
%     hold on 
%     plot(C_origin(k,1),C_origin(k,2),'ro');

end



for b = 1:10
    U(b) = mean(sqrt((C_final(:,1)-Hx(:,b)).^2 + (C_final(:,2)-Hy(:,b)).^2)) ;
    score(b) = real(1 - U(b)/(0.5*((1)^2 + (1)^2)));
end

[s, I] = max(score);

result = I-1;











